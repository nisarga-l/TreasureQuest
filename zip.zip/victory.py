
import tkinter as tk
from tkinter import messagebox

from theme import apply_background
from progress import complete_level, get_total_coins
from levels import LEVELS


def show_result(
    root, hero, score, steps, lives,
    won, level=1, collected_coins=0
):
    root.unbind("<KeyPress>")

    # Clear previous screen
    for widget in root.winfo_children():
        widget.destroy()

    # Magical temple background
    apply_background(root)

    # Main victory panel
    panel = tk.Frame(
        root,
        bg="#140B2D",
        padx=35,
        pady=15,
        highlightbackground="#FFD700",
        highlightthickness=3
    )
    panel.place(
        relx=0.5,
        rely=0.5,
        anchor="center"
    )

    # Heading
    tk.Label(
        panel,
        text="LEVEL COMPLETED!" if won else "GAME OVER",
        font=("Georgia", 27, "bold"),
        fg="#FFD700" if won else "#FF6688",
        bg="#140B2D"
    ).pack(pady=8)

    # Level name
    tk.Label(
        panel,
        text=f"LEVEL {level}: {LEVELS[level]['name']}",
        font=("Georgia", 17, "bold"),
        fg="#D9B9FF",
        bg="#140B2D"
    ).pack(pady=5)

    # Game results
    tk.Label(
        panel,
        text=(
            f"Hero: {hero}\n"
            f"Final Score: {score}\n"
            f"Steps Taken: {steps}\n"
            f"Lives Remaining: {lives}\n"
            f"Maze Coins Collected: {collected_coins}"
        ),
        font=("Arial", 14),
        fg="white",
        bg="#140B2D",
        justify="center"
    ).pack(pady=10)

    # Navigation functions
    def play_again():
        from maze import start_maze
        start_maze(root, hero, level)

    def change_hero():
        from game import character_selection
        character_selection(root)

    def main_menu():
        from main import show_welcome
        show_welcome(root)

    def next_level():
        if level < max(LEVELS):
            from maze import start_maze
            start_maze(root, hero, level + 1)

    # Common button design
    def make_button(text, command, color):
        return tk.Button(
            panel,
            text=text,
            command=command,
            font=("Arial", 12, "bold"),
            bg=color,
            fg="white",
            width=25,
            height=2,
            cursor="hand2"
        )

    # Victory rewards
    if won:

        tk.Label(
            panel,
            text="A MAGICAL TREASURE CHEST APPEARS!",
            font=("Arial", 12, "bold"),
            fg="#FFD875",
            bg="#140B2D"
        ).pack(pady=7)

        chest_icon = tk.Label(
            panel,
            text="🎁",
            font=("Segoe UI Emoji", 38),
            fg="#FFD700",
            bg="#140B2D"
        )
        chest_icon.pack(pady=3)

        chest_opened = False

        def open_chest():
            nonlocal chest_opened

            if chest_opened:
                return

            try:
                reward, unlocked = complete_level(
                    level,
                    collected_coins
                )

                total = get_total_coins()

            except Exception as error:
                messagebox.showerror(
                    "REWARD ERROR",
                    f"Could not claim the reward:\n{error}",
                    parent=root
                )
                return

            chest_opened = True

            chest_button.config(
                text="REWARD CLAIMED",
                state="disabled"
            )

            chest_icon.config(text="✨")

            reward_text = (
                "YOU OPENED THE TREASURE CHEST!\n\n"
                f"Coins earned: {reward}\n"
                f"Total wallet coins: {total}"
            )

            if unlocked:
                reward_text += (
                    "\n\nNEW HERO UNLOCKED!\n"
                    + "\n".join(unlocked)
                )

            if reward == 0:
                reward_text += (
                    "\n\nThis level's reward was already claimed."
                )

            messagebox.showinfo(
                "TREASURE REWARD",
                reward_text,
                parent=root
            )

        # Open treasure chest button
        chest_button = make_button(
            "OPEN TREASURE CHEST",
            open_chest,
            "#B8860B"
        )
        chest_button.pack(pady=6)

        # Next level button
        if level < max(LEVELS):

            next_button = make_button(
                f"NEXT LEVEL ({level + 1})",
                next_level,
                "#218B64"
            )

            next_button.pack(pady=6)

        else:
            tk.Label(
                panel,
                text="ALL THREE LEVELS COMPLETED!",
                font=("Georgia", 14, "bold"),
                fg="#65FF9D",
                bg="#140B2D"
            ).pack(pady=8)

    # Play again button
    make_button(
        "PLAY AGAIN",
        play_again,
        "#7545D8"
    ).pack(pady=5)

    # Change hero button
    make_button(
        "CHANGE HERO",
        change_hero,
        "#2585C5"
    ).pack(pady=5)

    # Main menu button
    make_button(
        "MAIN MENU",
        main_menu,
        "#C43C68"
    ).pack(pady=5)
