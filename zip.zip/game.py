
import tkinter as tk
from tkinter import messagebox
from pathlib import Path
from PIL import Image, ImageTk

from theme import apply_background
from progress import (
    load_progress,
    CHARACTER_REQUIREMENTS,
    unlock_character,
)
from levels import LEVELS

IMAGE_FOLDER = Path(__file__).parent / "assets" / "characters"

HEROES = [
    ("Mira the Explorer", "mira.png", "#2BADE0"),
    ("Luna the Star Mage", "luna.png", "#974BE0"),
    ("Ruby the Brave", "ruby.png", "#E04B75"),
]


def clear_screen(root):
    root.unbind("<KeyPress>")

    for widget in root.winfo_children():
        widget.destroy()

    apply_background(root)


def character_selection(root):
    clear_screen(root)

    data = load_progress()
    root.hero_images = []

    panel = tk.Frame(
        root,
        bg="#140B2D",
        padx=20,
        pady=15,
        highlightbackground="#FFD700",
        highlightthickness=2,
    )
    panel.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(
        panel,
        text="CHOOSE YOUR HERO",
        font=("Georgia", 27, "bold"),
        bg="#140B2D",
        fg="#FFD700",
    ).pack(pady=8)

    tk.Label(
        panel,
        text=f"COIN WALLET: {data['coins']:,}",
        font=("Arial", 15, "bold"),
        bg="#140B2D",
        fg="#FFD875",
    ).pack(pady=5)

    cards = tk.Frame(panel, bg="#140B2D")
    cards.pack(pady=10)

    for name, filename, color in HEROES:
        unlocked = name in data["unlocked_characters"]
        price = CHARACTER_REQUIREMENTS[name]

        card = tk.Frame(
            cards,
            bg="#30264D",
            padx=8,
            pady=8,
        )
        card.pack(side="left", padx=8)

        image_path = IMAGE_FOLDER / filename

        try:
            image = Image.open(image_path)
            image.thumbnail((150, 180))

            photo = ImageTk.PhotoImage(image)
            root.hero_images.append(photo)

            tk.Label(
                card,
                image=photo,
                bg="#30264D",
            ).pack(pady=5)

        except (OSError, ValueError):
            tk.Label(
                card,
                text="Image not found",
                bg="#30264D",
                fg="white",
                width=18,
                height=8,
            ).pack()

        tk.Label(
            card,
            text=name,
            bg="#30264D",
            fg="white",
            font=("Arial", 11, "bold"),
            wraplength=160,
        ).pack(pady=5)

        if unlocked:
            status = "FREE CHARACTER" if price == 0 else "UNLOCKED"
            button_text = "SELECT"
            button_color = color
            status_color = "#65FF9D"
        else:
            status = f"PRICE: {price:,} COINS"
            button_text = f"UNLOCK ({price:,})"
            button_color = "#A66A18"
            status_color = "#FFB6C8"

        tk.Label(
            card,
            text=status,
            bg="#30264D",
            fg=status_color,
            font=("Arial", 10, "bold"),
        ).pack(pady=5)

        def choose_character(hero=name):
            latest = load_progress()

            if hero in latest["unlocked_characters"]:
                level_selection(root, hero)
                return

            price_needed = CHARACTER_REQUIREMENTS[hero]

            if latest["coins"] < price_needed:
                messagebox.showinfo(
                    "Not Enough Coins",
                    f"{hero} costs {price_needed:,} coins.\n"
                    f"You have {latest['coins']:,} coins.\n\n"
                    f"You need {price_needed - latest['coins']:,} "
                    "more coins.",
                )
                return

            confirm = messagebox.askyesno(
                "Unlock Character",
                f"Spend {price_needed:,} coins to unlock {hero}?",
            )

            if not confirm:
                return

            success, message, updated_data = unlock_character(hero)

            messagebox.showinfo(
                "Character Unlock",
                message,
            )

            if success:
                character_selection(root)

        tk.Button(
            card,
            text=button_text,
            bg=button_color,
            fg="white",
            width=15,
            font=("Arial", 10, "bold"),
            command=choose_character,
            cursor="hand2",
        ).pack(pady=8)

    tk.Button(
        panel,
        text="MAIN MENU",
        width=20,
        bg="#7545D8",
        fg="white",
        font=("Arial", 11, "bold"),
        command=lambda: back_to_menu(root),
        cursor="hand2",
    ).pack(pady=8)


def level_selection(root, hero):
    clear_screen(root)

    data = load_progress()

    panel = tk.Frame(
        root,
        bg="#140B2D",
        padx=35,
        pady=20,
        highlightbackground="#FFD700",
        highlightthickness=2,
    )
    panel.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(
        panel,
        text="SELECT YOUR LEVEL",
        font=("Georgia", 26, "bold"),
        bg="#140B2D",
        fg="#FFD700",
    ).pack(pady=10)

    tk.Label(
        panel,
        text=f"Hero: {hero}\nCoins: {data['coins']:,}",
        font=("Arial", 13),
        bg="#140B2D",
        fg="white",
    ).pack(pady=8)

    for number, details in LEVELS.items():
        available = number <= data["highest_level"]

        def open_level(level_number=number):
            from maze import start_maze
            start_maze(root, hero, level_number)

        button_text = (
            f"LEVEL {number} - {details['name']}"
            if available
            else f"LEVEL {number} - LOCKED"
        )

        tk.Button(
            panel,
            text=button_text,
            font=("Arial", 13, "bold"),
            bg="#7545D8" if available else "#555066",
            fg="white",
            width=30,
            height=2,
            state="normal" if available else "disabled",
            command=open_level,
        ).pack(pady=6)

    tk.Button(
        panel,
        text="CHANGE HERO",
        font=("Arial", 12, "bold"),
        bg="#2585C5",
        fg="white",
        width=20,
        command=lambda: character_selection(root),
    ).pack(pady=10)


def back_to_menu(root):
    from main import show_welcome
    show_welcome(root)
