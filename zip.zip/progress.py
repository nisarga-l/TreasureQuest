
import json
from pathlib import Path
from levels import LEVELS

SAVE_FILE = Path(__file__).parent / "save_data.json"

CHARACTER_REQUIREMENTS = {
    "Mira the Explorer": 0,
    "Luna the Star Mage": 5000,
    "Ruby the Brave": 10000,
}


def load_progress():
    data = {
        "coins": 0,
        "highest_level": 1,
        "completed_levels": [],
        "unlocked_characters": ["Mira the Explorer"],
    }

    if SAVE_FILE.exists():
        try:
            with open(SAVE_FILE, "r", encoding="utf-8") as file:
                saved = json.load(file)

            if isinstance(saved, dict):
                data.update(saved)
        except (OSError, ValueError):
            pass

    if not isinstance(data.get("unlocked_characters"), list):
        data["unlocked_characters"] = ["Mira the Explorer"]

    if "Mira the Explorer" not in data["unlocked_characters"]:
        data["unlocked_characters"].append("Mira the Explorer")

    return data


def save_progress(data):
    with open(SAVE_FILE, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4)


def unlock_character(hero):
    data = load_progress()

    if hero not in CHARACTER_REQUIREMENTS:
        return False, "Unknown character.", data

    if hero in data["unlocked_characters"]:
        return True, f"{hero} is already unlocked!", data

    price = CHARACTER_REQUIREMENTS[hero]

    if data["coins"] < price:
        missing = price - data["coins"]
        return (
            False,
            f"You need {missing:,} more coins to unlock {hero}.",
            data,
        )

    data["coins"] -= price
    data["unlocked_characters"].append(hero)
    save_progress(data)

    return True, f"{hero} unlocked successfully!", data


def complete_level(level, collected_coins=0):
    data = load_progress()

    if level not in LEVELS:
        return 0, []

    if level in data["completed_levels"]:
        return 0, []

    bonus = LEVELS[level]["reward"]
    extra_coins = collected_coins * 25
    total_reward = bonus + extra_coins

    data["coins"] += total_reward
    data["completed_levels"].append(level)
    data["highest_level"] = min(
        3, max(data["highest_level"], level + 1)
    )

    save_progress(data)
    return total_reward, []


def get_total_coins():
    return load_progress()["coins"]
